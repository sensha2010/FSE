import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { ProjectComponent } from './ui/project/project.component';
import { TaskComponent } from './ui/task/task.component';
import { UserComponent } from './ui/user/user.component';
import { AddComponent } from './ui/task/add/add.component';

const routes:Routes = [
  { path:'', redirectTo:'task', pathMatch: 'full' },
  { path: 'task', component: TaskComponent },
  { path:'task/add', component: AddComponent },
  { path: 'project', component : ProjectComponent },
  { path: 'user', component: UserComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  declarations: [],
  exports:[ RouterModule]
})
export class AppRoutingModule { }
