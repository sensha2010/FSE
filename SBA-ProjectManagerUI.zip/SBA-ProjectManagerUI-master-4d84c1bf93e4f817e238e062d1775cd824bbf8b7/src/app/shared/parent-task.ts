export class ParentTask{
    ParentId: number;
    PTaskName: string;
    
}