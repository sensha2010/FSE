import { Injectable } from '@angular/core';
import { observable, of } from 'rxjs';
import { map,catchError } from "rxjs/operators";
import { HttpModule, Http, Headers, Response, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders,HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { throwError } from 'rxjs/internal/observable/throwError';
import { Users } from './user';
import { Projects } from './project';
import { ParentTask } from './parent-task';
import { Task } from './task';

@Injectable()
export class ProjectManagerService {

    baseUrl:any;
    requestOptions :RequestOptions;
    headers:HttpHeaders = new HttpHeaders({'Accept':'application/json', 'Content-Type':'application/json','Access-Control-Allow-Origin':'*'});

    constructor(private http: HttpClient){
        //this.requestOptions = new RequestOptions({headers:this.headers,withCredentials:true});
        //this.baseUrl = 'http://localhost:56748/api/';
        //this.baseUrl = 'http://localhost:56971/api/';
        this.baseUrl = 'http://localhost:8086/api/';
    }

    getUserDetails(): Observable<Users[]>{
      return this.http.get<Users[]>(this.baseUrl + 'project/users').pipe(
        catchError(this.handleError('getUserDetails',[]))
    );
  }

  getTaskDetails(): Observable<Task[]>{
    return this.http.get<Task[]>(this.baseUrl + 'project/task').pipe(
      catchError(this.handleError('getTaskDetails',[]))
    );
  }
  getTaskDetailById(id:any): Observable<Task>{
    return this.http.get<Task>(this.baseUrl + 'project/task/' + id).pipe(
      catchError(this.handleError('getTaskDetailById', null))
    );
  }

  getProjectDetails(): Observable<Projects[]>{
    return this.http.get<Projects[]>(this.baseUrl + 'project/projects').pipe(
      catchError(this.handleError('getProjectDetails',[]))
  );
  }

  getProjectDetailById(id:any): Observable<Projects>{
    return this.http.get<Projects>(this.baseUrl + 'project/project/'+ id).pipe(
      catchError(this.handleError('getProjectDetailById',null))
  );
  }

  getParentTaskDetails(): Observable<ParentTask[]>{
    return this.http.get<ParentTask[]>(this.baseUrl + 'project/parenttask').pipe(
      catchError(this.handleError('getParentTaskDetails',[]))
  );

  }
  addUser(user:any):Observable<any>{
      const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(user);
      console.log(user);
      return this.http.post<any>(this.baseUrl + 'project/user', body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('addUser', user))
        );
  }

  addTask(task: any): Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(task);
      console.log(task);
      return this.http.post<any>(this.baseUrl + 'project/task', body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('addTask', task))
        );
  }

  addParentTask(ptask: any): Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(ptask);
      console.log(ptask);
      return this.http.post<any>(this.baseUrl + 'project/parenttask', body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('addParentTask', ptask))
        );
  }  

  updateUser(user:any):Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(user);
      console.log(user);
      return this.http.put<any>(this.baseUrl + 'project/user/' + user.UserId, body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('updateUser', user))
        );
  }

  updateProject(project:any):Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(project);
      console.log(project);
      return this.http.put<any>(this.baseUrl + 'project/project/' + project.ProjectId, body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('updateUser', project))
        );
  }

  updateTask(task:any):Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
      var body = JSON.stringify(task);
      console.log(task);
      return this.http.put<any>(this.baseUrl + 'project/task/' + task.TaskId, body, {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('updateTask', task))
        );
  }

  deleteUser(id:any):Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json'});
      return this.http.delete<any>(this.baseUrl + 'project/user/' + id , {headers:headers}).pipe(map(
          (res:Response)=> res),
          catchError(this.handleError('deleteUser', id))
        );
  }

  addProject(project:any):Observable<any>{
    const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json', 'Access-Control-Allow-Origin':'*'});
    var body = JSON.stringify(project);
    console.log(project);
    return this.http.post<any>(this.baseUrl + 'project/projects', body, {headers:headers}).pipe(map(
        (res:Response)=> res),
        catchError(this.handleError('addProject', project))
      );
}

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead
      return of(result as T);
    };
  }
}
