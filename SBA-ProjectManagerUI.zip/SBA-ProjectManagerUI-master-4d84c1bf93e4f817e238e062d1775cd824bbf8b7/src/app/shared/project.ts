export class Projects{
    ProjectId: number;
    ProjectName: string;
    StartDate:string;
    EndDate:string;
    Priority:number;
    Status:string;
    UserId: number;
}