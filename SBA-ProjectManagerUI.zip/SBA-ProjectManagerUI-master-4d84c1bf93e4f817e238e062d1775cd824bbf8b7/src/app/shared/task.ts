export class Task{
    TaskId: number;
    ParentId: number;
    ProjectId: number;
    UserId: number;
    TaskName: string;
    StartDate:string;
    EndDate:string;
    Priority:number;
    Status:string;
}