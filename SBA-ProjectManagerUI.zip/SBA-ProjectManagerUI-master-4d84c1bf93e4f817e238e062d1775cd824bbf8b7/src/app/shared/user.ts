export class Users{
    UserId: number;
    EmployeeID: number;
    FirstName:string;
    LastName:string;
}