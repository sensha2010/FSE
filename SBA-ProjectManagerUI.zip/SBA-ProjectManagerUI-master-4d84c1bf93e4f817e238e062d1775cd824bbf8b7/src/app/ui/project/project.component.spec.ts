import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, FormGroup } from '@angular/forms';
import { RouterTestingModule } from "@angular/router/testing";
import { HttpClientModule } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
//import { Observable } from 'rxjs/internal/Observable';
import { Observable, of } from 'rxjs';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Projects } from '../../shared/project';
import { Users } from '../../shared/user';
import { Task } from '../../shared/task';
import { ProjectComponent } from './project.component';


describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let service : ProjectManagerService;
  let fixture: ComponentFixture<ProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectComponent ],
      imports:[RouterTestingModule, FormsModule, HttpClientModule],
      providers:[ProjectManagerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.get(ProjectManagerService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define dateRequired()', ()=>{
    component.isDateExist = false;
    component.dateRequired();
    expect(component.psDate).not.toBeNull();
  });

  it('should define dateRequired() without date', ()=>{
    component.isDateExist = true;
    component.dateRequired();
    expect(component.psDate).toBe('');
  });

  it('should define onpsDateChanged()', ()=>{
    component.psDate = '2019-04-25';
    component.peDate = '2019-04-23';
    component.onpsDateChanged();
  });

  it('should define onpeDateChanged()', ()=>{
    component.peDate = '2019-04-25';
    component.psDate = '2019-04-26';
    component.onpeDateChanged();
  });

  it('should define openUserSearch()', ()=>{
    component.openUserSearch();
    expect(component.username).toBe('');
  });

  it('should define search()', ()=>{
    component.username = 'Krishna Raj';
    component.users = [ { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    component.search();
    expect(component.users.length).toBeGreaterThan(0);
  });

  it('should define setUser()', ()=>{
    let user: Users = new Users();
    user.UserId = 2;
    user.FirstName = 'Arun';
    user.LastName = 'Kumar';
    user.EmployeeID = 125632;
    component.setUser(user);
    expect(component.mname).toBe('Arun Kumar');
  });

  it('should define reset()', ()=>{
    component.reset();
    expect(component.pname).toBe('');
  });

  it('should define sortByStartDate()', ()=>{
    component.projects = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 10, "StartDate": '2019-04-25', "EndDate": "2019-04-26" },
      { "ProjectId": 2, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29" }
    ];
    component.sortByStartDate();
  });

  it('should define sortByEndDate()', ()=>{
    component.projects = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26" },
      { "ProjectId": 2, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29" }
    ];
    component.sortByEndDate();
  });

  it('should define sortyByPriority()', ()=>{
    component.projects = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 10, "StartDate": '2019-04-25', "EndDate": "2019-04-26" },
      { "ProjectId": 3, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29" }
    ];
    component.sortyByPriority();
  });

  it('should define sortByStatus()', ()=>{
    component.projects = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 10, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status": "In Progress" },
      { "ProjectId": 3, "ProjectName":'CLS', "Priority": 15, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed" },
      { "ProjectId": 2, "ProjectName":'EMS', "Priority": 20, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status": "In Progress" }
    ];
    component.sortByStatus();
  });

  it('should define getUsersList()', ()=>{
    let mockResponse : Users[] = [
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    spyOn(service, 'getUserDetails').and.returnValue(of(mockResponse));
    component.getUsersList();
  });

  it('should define getProjectDetails()', ()=>{
    let mockResponse : Projects[] = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1 },
      { "ProjectId": 2, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2 }
    ];
    spyOn(service,'getProjectDetails').and.returnValue(of(mockResponse));
    component.getProjectDetails();
  });

  it('should define add()', ()=>{
    component.pname = 'AIIMS';
    component.psDate = '2019-04-26';
    component.peDate = '201-04-27';
    component.priority = 15;
    component.mnameSelectedId = 2;
    component.mname = 'Krishna Raj';
    spyOn(service,'addProject').and.returnValue(of(''));
    component.add();
  });

  it('should define update()', ()=>{
    component.pid = 2;
    component.pname = 'AIIMS';
    component.psDate = '2019-04-26';
    component.peDate = '201-04-27';
    component.priority = 15;
    component.mnameSelectedId = 2;
    component.mname = 'Krishna Raj';
    component.projectStatus = 'In Progress';
    spyOn(service,'updateProject').and.returnValue(of(''));
    component.update();
  });

  it('should define updateProject()', ()=>{
    let mockResponse: Projects[] = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1 },
      { "ProjectId": 3, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2 }
    ];
    let mockUserResponse : Users[] = [
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
      { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    spyOn(service, 'getProjectDetails').and.returnValue(of(mockResponse));
    spyOn(service,'getUserDetails').and.returnValue(of(mockUserResponse));
    component.updateProject(2);
  });

  it('should define suspendProject()', ()=>{
    let mockProject: Projects = new Projects();
    mockProject.ProjectId = 2;
    mockProject.Priority = 10;
    mockProject.ProjectName = 'AIIMS';
    mockProject.StartDate = '2019-04-28';
    mockProject.EndDate = '2019-04-29';
    mockProject.Status = 'In Progress';
    mockProject.UserId = 2;
    spyOn(service,'updateProject').and.returnValue(of(''));
    component.suspendProject(mockProject);
  });

  it('should define onProjectChanged()', ()=>{
    component.project = 'CLS';
    component.projects = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1 },
      { "ProjectId": 3, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2 }
    ];
    component.onProjectChanged();
    expect(component.projects.length).toBeGreaterThan(0);
  });
});
