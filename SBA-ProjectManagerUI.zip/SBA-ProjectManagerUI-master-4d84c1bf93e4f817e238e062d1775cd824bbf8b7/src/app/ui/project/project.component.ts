import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common';
import { FormsModule, FormGroup } from '@angular/forms';
import { Router } from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Projects } from '../../shared/project';
import { Users } from '../../shared/user';
import { Task } from '../../shared/task';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  pid:number = 0;
  pname: string = '';
  priority:number  = 0;
  mname:any  = '';
  mnameSelectedId: number = 0;
  projects: any[] = [];
  project: string = '';
  users: Users[] = [];
  //noOfTasks: number = 0;
  isDateExist:boolean = false;
  isEditClicked:boolean = false;
  username: any = '';
  psDate: any = '';
  peDate: any = '';
  projectStatus : string  = '';
  constructor(private service:ProjectManagerService, private router:Router) { }

  ngOnInit() {

    localStorage.setItem("edittask",undefined);
    //this.getUsersList();
    this.getProjectDetails();

  }

  getProjectDetails(){
    this.users = [];
    this.projects = [];
    let numTasks: number = 0;
    let numCompletedTasks : number  = 0;
    this.service.getProjectDetails().subscribe((res:Projects[])=>{
    res.map(p=>{
      let project: any = {};
      project = {
        "ProjectId": p.ProjectId,
        "ProjectName": p.ProjectName,
        "Priority": p.Priority,
        "StartDate": p.StartDate,
        "EndDate": p.EndDate,
        "Status": p.Status,
        "UserId": p.UserId,
      }
      this.service.getTaskDetails().subscribe((res:Task[])=>{
        numTasks = 0;
        numCompletedTasks = 0;
        res.map(t=>{
          if(t.ProjectId == project.ProjectId)
          {
            if(t.Status == 'Completed')
            {
              numCompletedTasks++;
            }
            numTasks++;
          }
          
        });
        project = Object.assign(project,{"noOfTasks": numTasks, "noOfCompletedTasks": numCompletedTasks});
        this.projects.push(project);
      }),catchError((err:any)=> Observable.throw(err));
      // let project: Projects = new Projects();
      // project.ProjectId = p.ProjectId;
      // project.ProjectName = p.ProjectName;
      // project.Priority = p.Priority;
      // project.StartDate = p.StartDate;
      // project.EndDate = p.EndDate;
      // project.Status = p.Status;
      // project.UserId = p.UserId;
      // this.projects.push(project);
    });   
  }),catchError((err:any)=>
    Observable.throw(err)
  );
  }


  dateRequired(){
    if(this.isDateExist == false)
    {
      this.isDateExist = true;
      this.psDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
      this.peDate = formatDate(new Date().setDate(new Date().getDate() + 1), 'yyyy-MM-dd', 'en');
    }
    else
    {
      this.isDateExist = false;
      this.psDate = '';
      this.peDate = '';
    }
  }

  selectUser(){

  }

  onpsDateChanged(){
    if(this.psDate != '' && this.peDate != '')
      {
        if (this.psDate > this.peDate) {
          alert("Start Date should be less than End Date");
        }
        return {};
      }
  }

  onpeDateChanged(){
    if(this.psDate != '' && this.peDate != '')
    {
      if (this.psDate > this.peDate) {
        alert("End Date to should be greater than Start Date");
      }
      return {};
    }
  }

  getUsersList(){
    this.service.getUserDetails().subscribe((res:Users[])=>{
      res.map(u=>{
        let user: Users = new Users();
        user.UserId = u.UserId;
        user.FirstName = u.FirstName;
        user.LastName = u.LastName;
        user.EmployeeID = u.EmployeeID;
        //user.ProjectId = u.ProjectId;
        this.users.push(user);
      });   
    }),catchError((err:any)=>
      Observable.throw(err)
    );
  }

  openUserSearch(){
    this.users = [];
    this.username = '';
    this.getUsersList();
  }

  search(){
    let usersTemp : Users[] = [];
    if(this.username != undefined || this.username != '')
    {
      usersTemp = this.users.filter(uu=>{
        if((uu.FirstName.toLowerCase() + ' ' + uu.LastName.toLowerCase()).match(this.username.toLowerCase()))
        {
          return uu;
        }
      });
      this.users = [];
      this.users = usersTemp;
    }
    else{
      this.getUsersList();
    }
  }

  setUser(user: Users){
    //console.log(user);
    this.mname = '';
    this.mname = user.FirstName + ' ' +  user.LastName;
    this.mnameSelectedId = user.UserId;
  }

  add(){
    let project : Projects = new Projects();
    if((this.pname != '' || this.pname != undefined) && 
    (this.psDate != '' && this.peDate != undefined) &&
    (this.priority > 0) &&
    (this.mname!= '' && this.mname != undefined))
    {
        project.ProjectName = this.pname;
        project.StartDate = this.psDate;
        project.EndDate = this.peDate;
        project.Priority = this.priority;
        project.Status = 'In Progress';
        project.UserId = this.mnameSelectedId;
        this.service.addProject(project).subscribe((res:any)=>{
          //this.updateProjectUserDetails();
          this.getProjectDetails();
          this.reset();
        }),catchError((err:any)=>
          Observable.throw(err)
        );  
    }
    else
    alert('All are required field(s)');
  }


  // updateProjectUserDetails(){
  //   let user : Users = new Users();
  //   let proj: Projects = new Projects();
    
  //   this.service.getProjectDetails().subscribe((res:Projects[])=>{
  //     proj = res.filter(pp=> pp.ProjectName.toLowerCase() == this.pname.toLowerCase())[0];
  //     this.service.getUserDetails().subscribe((res:Users[])=>{
  //       user = res.filter(uu=> uu.UserId == this.mnameSelectedId)[0];
  //       //user.ProjectId = proj.ProjectId;
  //       this.service.updateUser(user).subscribe((res:any)=>{
  //         this.getProjectDetails();
  //         this.reset();
  //       }),catchError((err:any)=>
  //         Observable.throw(err)
  //       );
  //     }), catchError((err:any)=> Observable.throw(err));
  //   }),catchError((err:any)=>Observable.throw(err));
  // }

  update(){
    let project : Projects = new Projects();
    if((this.pname != '' || this.pname != undefined) && 
    (this.psDate != '' && this.peDate != undefined) &&
    (this.priority > 0) &&
    (this.mname!= '' && this.mname != undefined))
    {
        project.ProjectId = this.pid;
        project.ProjectName = this.pname;
        project.StartDate = this.psDate;
        project.EndDate = this.peDate;
        project.Priority = this.priority;
        project.Status = this.projectStatus;
        project.UserId = this.mnameSelectedId;
        this.service.updateProject(project).subscribe((res:any)=>{
          //this.updateProjectUserDetails();
          this.getProjectDetails();
          this.reset();
        }),catchError((err:any)=>
          Observable.throw(err)
        );  
    }
    else
    alert('All are required field(s)');
  }

  reset(){
    this.pname = '';
    this.psDate = '';
    this.peDate = '';
    this.mname = '';
    this.mnameSelectedId = 0;
    this.priority = 0;
    this.isDateExist = false;
    this.isEditClicked = false;
  }

  updateProject(id: number){
    let result : Projects = new Projects();
    let user : Users = new Users();
    this.isEditClicked = true;
    
    this.service.getProjectDetails().subscribe((res:Projects[])=>{
      result = res.filter(u=>u.ProjectId == id)[0];
      this.pid = result.ProjectId;
      this.pname = result.ProjectName;
      this.psDate = result.StartDate.split('T')[0];
      this.peDate = result.EndDate.split('T')[0];
      if(this.psDate != undefined && this.peDate  != undefined)
        this.isDateExist = true;
      this.priority = result.Priority;
      this.projectStatus = result.Status;
      this.mnameSelectedId = result.UserId;
      this.service.getUserDetails().subscribe((res:Users[])=>{
        user = res.filter(uu=> uu.UserId == result.UserId)[0];
        //this.mnameSelectedId = user.UserId;
        this.mname = user.FirstName + ' ' + user.LastName;
      }),catchError((err:any)=> Observable.throw(err));
    }),catchError((err:any)=> Observable.throw(err));
  }

  suspendProject(p: Projects){
      p.Status = 'Completed';
      this.service.updateProject(p).subscribe((res:any)=>{
        this.getProjectDetails();
        //this.updateProjectUserDetails();
      }),catchError((err:any)=>
        Observable.throw(err)
      );
  }

  onProjectChanged(){
    if(this.project != '')
    {
      let projArr:Projects[] = [];
      this.projects.filter(p=>{
        if(p.ProjectName.toLowerCase().match(this.project.toLowerCase()) 
        || p.StartDate.split('T')[0] == this.project || p.EndDate.split('T')[0] == this.project
        || p.Priority == this.priority || p.Status.toLowerCase().match(this.project.toLowerCase())){
          
          let project:Projects = new Projects();
          project.ProjectId = p.ProjectId;
          project.ProjectName = p.ProjectName;
          project.StartDate = p.StartDate;
          project.EndDate = p.EndDate;
          project.Priority = p.Priority;
          project.Status = p.Status;
          this.projects = [];
          projArr.push(project);
        }
      });
      this.projects = [];
      this.projects = projArr;
    }
    else if(this.project == '')
    this.ngOnInit();
  }

  sortByStartDate(){
    this.projects.sort((a,b)=>{
      return <any>new Date(b.StartDate) - <any>new Date(a.StartDate)
    });
  }

  sortByEndDate(){
    this.projects.sort((a,b)=>{
      return <any>new Date(b.EndDate) - <any>new Date(a.EndDate)
    });
  }

    sortyByPriority(){
      this.projects.sort((a,b)=>{
        if(a.Priority > b.Priority) return -1;
        else if(a.Priority < b.Priority) return 1;
        else return 0;
      });
    }

    sortByStatus(){
      this.projects.sort((a,b)=>{
        if(a.Status.toLowerCase() > b.Status.toLowerCase()) return -1;
        else if(a.Status.toLowerCase() < b.Status.toLowerCase()) return 1;
        else return 0;
      });
    }
}
