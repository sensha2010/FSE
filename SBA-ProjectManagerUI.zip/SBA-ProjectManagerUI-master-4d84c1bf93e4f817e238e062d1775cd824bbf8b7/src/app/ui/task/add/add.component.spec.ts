import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, FormGroup } from '@angular/forms';
import { RouterTestingModule } from "@angular/router/testing";
import { HttpClientModule } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ProjectManagerService } from '../../../shared/project-manager.service';
import { Projects } from '../../../shared/project';
import { ParentTask } from '../../../shared/parent-task';
import { Users } from '../../../shared/user';
import { Task } from '../../../shared/task';

import { AddComponent } from './add.component';

describe('AddComponent', () => {
  let component: AddComponent;
  let fixture: ComponentFixture<AddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddComponent ],
      imports:[RouterTestingModule, FormsModule, HttpClientModule],
      providers:[ProjectManagerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
