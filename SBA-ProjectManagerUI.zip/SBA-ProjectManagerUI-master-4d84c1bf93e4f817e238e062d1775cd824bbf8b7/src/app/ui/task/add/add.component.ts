import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common';
import { FormsModule, FormGroup } from '@angular/forms';
import { Router } from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ProjectManagerService } from '../../../shared/project-manager.service';
import { Projects } from '../../../shared/project';
import { ParentTask } from '../../../shared/parent-task';
import { Users } from '../../../shared/user';
import { Task } from '../../../shared/task';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  
  pnameSelected: any = '';
  task: any = '';
  tasks: Task[] = [];
  projects: Projects[] = [];
  newProject: any = '';
  isParentTask: boolean = true;
  priority: number = 0;
  currentProjectID : number = 0;
  ptSelected: any = '';
  ptasks: ParentTask[] = [];
  psDate: any = '';
  peDate: any = '';
  users: Users[] = [];
  status: string = '';
  mname: any = '';
  userSelectedId: number = 0;
  username:any = '';
  project: any = '';
  parenttask: any = '';
  parentSearchTask: any = '';
  isEditClicked: boolean = false;
  updateStatus: any = '';
  updateTaskId: number  = 0;
  updateParentTaskId: number = 0;

  constructor(private service:ProjectManagerService, private router:Router) { }

  ngOnInit() {
    this.newProject = '';
    let taskID = localStorage.getItem("edittask");
    let user: Users = new Users();
    
    if(taskID === 'undefined') {
      this.getUsersList();
      this.getParentTaskList();
      this.getProjectDetails();  
    }
    else
    {
      this.service.getTaskDetailById(taskID).subscribe((res:Task)=>{
        this.updateTaskId = res.TaskId;
        this.status = res.Status;
        this.updateParentTaskId = res.ParentId;
        this.isParentTask = false;
        this.userSelectedId = res.UserId;
        this.psDate = res.StartDate;
        this.peDate = res.EndDate;
        this.task = res.TaskName;
        this.priority = res.Priority;
        this.psDate = res.StartDate.split('T')[0];
        this.peDate = res.EndDate.split('T')[0];
        this.updateStatus = res.Status;
        this.service.getParentTaskDetails().subscribe((resptask:ParentTask[])=>{
          let pt: ParentTask = new ParentTask();
          pt = resptask.filter(p=> p.ParentId == res.ParentId)[0];
          if(pt != undefined)
          {
            this.parenttask = pt.PTaskName;
          }
          else
            {
              this.isParentTask = false;
              this.parenttask =  '';
            }
          this.service.getUserDetails().subscribe((resUsers:Users[])=>{
              user = resUsers.filter(uu=> uu.UserId == this.userSelectedId)[0];
              this.mname = user.FirstName + ' ' + user.LastName;
              this.service.getProjectDetailById(res.ProjectId).subscribe((res:Projects)=>{
              this.newProject = res.ProjectName;
              this.project = this.newProject;
          }),catchError((err:any)=> Observable.throw(err));
        }),catchError((err:any)=>{
          Observable.throw(err)
          return '';
        });
      //this.userSelectedId = user.UserId;
      }),catchError((err:any)=> Observable.throw(err));
    });                 
  }
}

  getProjectDetails(){
    this.users = [];
    this.projects = [];
    this.service.getProjectDetails().subscribe((res:Projects[])=>{
    //console.log(res);
    res.map(p=>{
      let project: Projects = new Projects();
      project.ProjectId = p.ProjectId;
      project.ProjectName = p.ProjectName;
      project.Priority = p.Priority;
      project.StartDate = p.StartDate;
      project.EndDate = p.EndDate;
      project.Status = p.Status;
      project.UserId = p.UserId;
      this.projects.push(project);
    });   
  }),catchError((err:any)=>
    Observable.throw(err)
  );
  }

  getUsersList(){
    this.service.getUserDetails().subscribe((res:Users[])=>{
      res.map(u=>{
        let user: Users = new Users();
        user.UserId = u.UserId;
        user.FirstName = u.FirstName;
        user.LastName = u.LastName;
        user.EmployeeID = u.EmployeeID;
        //user.ProjectId = u.ProjectId;
        this.users.push(user);
      });   
    }),catchError((err:any)=>
      Observable.throw(err)
    );
  }

getParentTaskList(){
  this.service.getParentTaskDetails().subscribe((res:ParentTask[])=>{
    res.map(pp=>{
      let pt: ParentTask = new ParentTask();
      pt.ParentId = pp.ParentId;
      pt.PTaskName = pp.PTaskName;
      this.ptasks.push(pt);
    });   
    }),catchError((err:any)=>
      Observable.throw(err)
    );
  }

  chkParentTask(){
    if(this.isParentTask == false)
    {
      this.isParentTask = true;
      this.priority = 0;
      this.parenttask = '';
      this.psDate = '';
      this.peDate = '';
    } 
    else
    {
      this.isParentTask = false;
      this.priority = 0;
      this.psDate = '';
      this.peDate = '';
      this.psDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
      this.peDate = formatDate(new Date().setDate(new Date().getDate() + 1), 'yyyy-MM-dd', 'en');
    }
  }

  onpsDateChanged(){
    if(this.psDate != '' && this.peDate != '')
      {
        if (this.psDate > this.peDate) {
          alert("Start Date should be less than End Date");
        }
        return {};
      }
  }

  onpeDateChanged(){
    if(this.psDate != '' && this.peDate != '')
    {
      if (this.psDate > this.peDate) {
        alert("End Date to should be greater than Start Date");
      }
      return {};
    }
  }

  openUserSearch(){
    this.users = [];
    this.username = '';
    this.getUsersList();
  }

  openProjectSearch(){
    this.projects = [];
    this.project = '';
    this.getProjectDetails();
  }

  openParentSearch(){
    this.ptasks = [];
    this.parenttask = '';
    this.getParentTaskList();
  }

  search(){
    let usersTemp : Users[] = [];
    if(this.username != undefined || this.username != '')
    {
      usersTemp = this.users.filter(uu=>{
        if((uu.FirstName.toLowerCase() + ' ' + uu.LastName.toLowerCase()).match(this.username.toLowerCase()))
        {
          return uu;
        }
      });
      this.users = [];
      this.users = usersTemp;
    }
    else{
      this.getUsersList();
    }
  }

  searchProject(){
    let projectTemp : Projects[] = [];
    if(this.project != undefined || this.project != '')
    {
      projectTemp = this.projects.filter(pp=>{
        if((pp.ProjectName.toLowerCase().match(this.project.toLowerCase())))
        {
          return pp;
        }
      });
      this.projects = [];
      this.projects = projectTemp;
    }
    else{
      this.getProjectDetails();
    }
  }

  searchParentTask(){
    let pTaskTemp : ParentTask[] = [];
    if(this.parentSearchTask != undefined || this.parentSearchTask != '')
    {
      pTaskTemp = this.ptasks.filter(pt=>{
        if((pt.PTaskName.toLowerCase().match(this.parentSearchTask.toLowerCase())))
        {
          return pt;
        }
      });
      this.ptasks = [];
      this.ptasks = pTaskTemp;
    }
    else{
      this.getParentTaskList();
    }
  }

  setUser(user: Users){
    //console.log(user);
    this.mname = '';
    this.mname = user.FirstName + ' ' +  user.LastName;
    this.userSelectedId = user.UserId;
  }

  setProject(project: Projects){
    //console.log(project);
    this.project = '';
    this.currentProjectID = 0;
    this.project = project.ProjectName;
    this.currentProjectID = project.ProjectId;
  }

  setParentTask(ptask: ParentTask){
    this.parenttask = '';
    this.parenttask = ptask.PTaskName;
  }

  add(){
    let task : Task = new Task();
    let ptask : ParentTask = new ParentTask();
    if(((this.project != '' || this.project != undefined) &&
    (this.task != '' || this.task != undefined) && 
    (this.psDate != '' && this.peDate != undefined) &&
    (this.priority > 0) || (!this.isParentTask)) &&
    (this.mname!= '' && this.mname != undefined))
    {
          task.TaskName = this.task;
          task.ProjectId = this.currentProjectID;
          this.service.getParentTaskDetails().subscribe((res:ParentTask[])=>{
            let pt : ParentTask = new ParentTask();
            if(this.parenttask != '' && this.parenttask != undefined)
            {
              pt = res.filter(pp=> pp.PTaskName == this.parenttask)[0];
              task.ParentId = pt.ParentId;
            }
            task.Priority = this.priority;
            task.StartDate = this.psDate;
            task.EndDate = this.peDate;
            task.Status = 'In Progress';
            task.UserId = this.userSelectedId;
            this.service.addTask(task).subscribe((res:any)=>{
              //this.updateTaskUserDetails();
              this.router.navigate(['task']);
              this.reset();
            }),catchError((err:any)=>
              Observable.throw(err)
            );   
          }),catchError((err:any)=> Observable.throw(err));
          
    }
    else if(this.isParentTask)
      {
          ptask.PTaskName = this.task;
          this.service.addParentTask(ptask).subscribe((res:any)=>{
            this.getParentTaskList();
            this.reset();
          }),catchError((err:any)=>
            Observable.throw(err)
          );  
      }  
    else
    alert('All are required field(s)');
  }


  update(){
    let task : Task = new Task();
    let ptask : ParentTask = new ParentTask();
    if(((this.project != '' || this.project != undefined) &&
    (this.task != '' || this.task != undefined) && 
    (this.psDate != '' && this.peDate != undefined) &&
    (this.priority > 0) || (!this.isParentTask)) &&
    (this.mname!= '' && this.mname != undefined))
    {
        task.TaskId = this.updateTaskId;
        task.TaskName = this.task;
        task.ProjectId = this.currentProjectID;
        task.Priority = this.priority;
        task.StartDate = this.psDate;
        task.EndDate = this.peDate;
        task.Status = this.status;
        task.UserId = this.userSelectedId;
        this.service.getParentTaskDetails().subscribe((res:ParentTask[])=>{
          let pt : ParentTask = new ParentTask();
          if(res.length > 0 && this.parenttask != '')
          {
            pt = res.filter(pp=> pp.PTaskName == this.parenttask)[0];
            task.ParentId = pt.ParentId;
          }
          this.service.updateTask(task).subscribe((res:any)=>{
            //this.updateTaskUserDetails();
             this.router.navigate(['task']);
              this.reset();
          }),catchError((err:any)=>
          Observable.throw(err)
        );
      }),catchError((err:any)=> Observable.throw(err));
        
    }
    else if(this.isParentTask)
      {
          ptask.PTaskName = this.task;
          this.service.addParentTask(ptask).subscribe((res:any)=>{
            this.getParentTaskList();
            this.reset();
          }),catchError((err:any)=>
            Observable.throw(err)
          );  
      }  
    else
    alert('All are required field(s)');
  }

  // updateTaskUserDetails(){
  //   let resUser : Users = new Users();
  //   let resTask: Task = new Task();
    
  //   this.service.getTaskDetails().subscribe((res:Task[])=>{
  //     resTask = res.filter(tt=> tt.TaskName.toLowerCase() == this.task.toLowerCase())[0];
  //     this.service.getUserDetails().subscribe((res:Users[])=>{
  //       console.log(res);
  //       console.log(this.userSelectedId);
  //       resUser = res.filter(uu=> uu.UserId == this.userSelectedId)[0];
  //       console.log(resUser);
  //       resUser.TaskId = resTask.TaskId;
  //         this.service.updateUser(resUser).subscribe((res:any)=>{
  //           this.router.navigate(['task']);
  //           this.reset();
  //         }),catchError((err:any)=>
  //           Observable.throw(err)
  //         );
  //     }), catchError((err:any)=> Observable.throw(err));
  //   }),catchError((err:any)=>Observable.throw(err));
  // }

  reset(){
    this.project = '';
    this.psDate = '';
    this.peDate = '';
    this.mname = '';
    this.priority = 0;
    this.task = '';
    this.isEditClicked = false;
  }

}
