import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, FormGroup } from '@angular/forms';
import { RouterTestingModule } from "@angular/router/testing";
import { HttpClientModule } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
//import { Observable } from 'rxjs/internal/Observable';
import { Observable, of } from 'rxjs';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Projects } from '../../shared/project';
import { ParentTask } from '../../shared/parent-task';
import { Users } from '../../shared/user';
import { Task } from '../../shared/task';
import { TaskComponent } from './task.component';

describe('TaskComponent', () => {
  let component: TaskComponent;
  let service: ProjectManagerService;
  let fixture: ComponentFixture<TaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskComponent ],
      imports:[RouterTestingModule, FormsModule, HttpClientModule],
      providers:[ProjectManagerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.get(ProjectManagerService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define getTaskDetails()', ()=>{
    component.currentProjectID = 2;
    let mockResponse : Task[] = [
      { "ProjectId": 2, "TaskId":1, "TaskName":'UI Design', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1, "ParentId":0 },
      { "ProjectId": 3,  "TaskId":2, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2, "ParentId": 0 }
    ];
    spyOn(service,'getTaskDetails').and.returnValue(of(mockResponse));
    component.getTaskDetails();
  });

  it('should define getProjectDetails()', ()=>{
    let mockResponse : Projects[] = [
      { "ProjectId": 2, "ProjectName":'AIIMS', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1 },
      { "ProjectId": 2, "ProjectName":'CLS', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2 }
    ];
    spyOn(service,'getProjectDetails').and.returnValue(of(mockResponse));
    component.getProjectDetails();
  });

  it('should define openProjectSearch()', ()=>{
    component.openProjectSearch();
    expect(component.projectSearch).toBe('');
  });

  it('should define sortByStartDate()', ()=>{
    component.tasks = [
      { "ProjectId": 2, "TaskId":1, "TaskName":'UI Design', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1, "ParentId":0 },
      { "ProjectId": 3,  "TaskId":2, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2, "ParentId": 0 }
    ];
    component.sortByStartDate();
  });

  it('should define sortByEndDate()', ()=>{
    component.tasks = [
      { "ProjectId": 2, "TaskId":1, "TaskName":'UI Design', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1, "ParentId":0 },
      { "ProjectId": 3,  "TaskId":2, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2, "ParentId": 0 }
    ];
    component.sortByEndDate();
  });

  it('should define sortyByPriority()', ()=>{
    component.tasks = [
      { "ProjectId": 2, "TaskId":1, "TaskName":'UI Design', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1, "ParentId":0 },
      { "ProjectId": 3,  "TaskId":2, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2, "ParentId": 0 },
      { "ProjectId": 3,  "TaskId":3, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-29', "EndDate": "2019-05-30", "Status": "Completed", "UserId":2, "ParentId": 0 }
    ];
    component.sortyByPriority();
  });

  it('should define sortByStatus()', ()=>{
    component.tasks = [
      { "ProjectId": 2, "TaskId":1, "TaskName":'UI Design', "Priority": 15, "StartDate": '2019-04-25', "EndDate": "2019-04-26", "Status":'In Progress', "UserId":1, "ParentId":0 },
      { "ProjectId": 3,  "TaskId":2, "TaskName":'Coding', "Priority": 20, "StartDate": '2019-04-27', "EndDate": "2019-04-29", "Status": "Completed", "UserId":2, "ParentId": 0 }
    ];
    component.sortByStatus();
  });

  it('should define setProject()', ()=>{
    let mockProject = new Projects();
    mockProject.ProjectId = 1;
    mockProject.ProjectName = 'AIIMS';
    component.setProject(mockProject);
    expect(component.currentProjectID).toBe(1);
  });

  it('should define endTask()', ()=>{
    let mockTask : Task = new Task();
    mockTask.TaskId = 1;
    mockTask.TaskName = 'Testing';
    mockTask.ProjectId = 2;
    mockTask.Priority = 10;
    mockTask.StartDate = '2019-04-30';
    mockTask.EndDate = '2019-05-02';
    mockTask.Status = 'In Progress';
    spyOn(service, 'updateTask').and.returnValue(of(''));
    component.endTask(mockTask);
  });
});
