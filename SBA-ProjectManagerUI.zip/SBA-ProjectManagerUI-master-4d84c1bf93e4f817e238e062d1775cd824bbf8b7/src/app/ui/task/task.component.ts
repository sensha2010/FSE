import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common';
import { FormsModule, FormGroup } from '@angular/forms';
import { Router } from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Projects } from '../../shared/project';
import { ParentTask } from '../../shared/parent-task';
import { Users } from '../../shared/user';
import { Task } from '../../shared/task';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  project: any = '';
  projectSearch: any = '';
  tasks: Task[] = [];
  projects: Projects[] = [];
  currentProjectID: number = 0;

  constructor(private service:ProjectManagerService, private router:Router) { }

  ngOnInit() {
    localStorage.setItem("edittask",undefined);
    this.getProjectDetails();
  }

  getTaskDetails(){
    this.tasks = [];
    this.service.getTaskDetails().subscribe((res:Task[])=>{
    res.map(t=>{
      if(t.ProjectId == this.currentProjectID)
      {
        let task: Task = new Task();
        task.TaskId = t.TaskId;
        task.TaskName = t.TaskName;
        task.ProjectId = t.ProjectId;
        task.ParentId = t.ParentId;
        task.UserId = t.UserId;
        task.Priority = t.Priority;
        task.StartDate = t.StartDate;
        task.EndDate = t.EndDate;
        task.Status = t.Status;
        this.tasks.push(task);
      }
    });   
  }),catchError((err:any)=>
    Observable.throw(err)
  );
  }

  getProjectDetails(){
    this.projects = [];
    this.service.getProjectDetails().subscribe((res:Projects[])=>{
    res.map(p=>{
      let project: Projects = new Projects();
      project.ProjectId = p.ProjectId;
      project.ProjectName = p.ProjectName;
      project.Priority = p.Priority;
      project.StartDate = p.StartDate;
      project.EndDate = p.EndDate;
      project.Status = p.Status;
      project.UserId = p.UserId;
      this.projects.push(project);
    });   
  }),catchError((err:any)=>
    Observable.throw(err)
  );
  }

  openProjectSearch(){
    this.projects = [];
    this.projectSearch = '';
    this.getProjectDetails();
  }

  searchProject(){
    let projTemp : Projects[] = [];
    if(this.projectSearch != undefined || this.projectSearch != '')
    {
      projTemp = this.projects.filter(pp=>{
        if((pp.ProjectName.toLowerCase()).match(this.projectSearch.toLowerCase()))
        {
          return pp;
        }
      });
      this.projects = [];
      this.projects = projTemp;
    }
    else{
      this.getProjectDetails();
    }
  }

  sortByStartDate(){
    this.tasks.sort((a,b)=>{
      return <any>new Date(b.StartDate) - <any>new Date(a.StartDate)
    });
  }

  sortByEndDate(){
    this.tasks.sort((a,b)=>{
      return <any>new Date(b.EndDate) - <any>new Date(a.EndDate)
    });
  }

  sortyByPriority(){
    this.tasks.sort((a,b)=>{
      if(a.Priority > b.Priority) return -1;
      else if(a.Priority < b.Priority) return 1;
      else return 0;
    });
  }

  sortByStatus(){
    this.tasks.sort((a,b)=>{
      if(a.Status.toLowerCase() > b.Status.toLowerCase()) return -1;
      else if(a.Status.toLowerCase() < b.Status.toLowerCase()) return 1;
      else return 0;
    });
  }

  setProject(project: Projects){
    this.project = '';
    this.currentProjectID = 0;
    this.projectSearch = project.ProjectName;
    this.project = project.ProjectName;
    this.currentProjectID = project.ProjectId;
    this.getTaskDetails();
  }

  editTask(id: any){
    localStorage.setItem("edittask",id);
    console.log(id);
    this.router.navigate(["task/add"]);
  }

  endTask(t: Task){
    t.Status = 'Completed';
    this.service.updateTask(t).subscribe((res:any)=>{
      this.getTaskDetails();
    }),catchError((err:any)=> Observable.throw(err));
  }

}
