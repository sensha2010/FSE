import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, FormGroup } from '@angular/forms';
import { RouterTestingModule } from "@angular/router/testing";
import { HttpClientModule } from '@angular/common/http';
import { catchError } from 'rxjs/internal/operators/catchError';
//import { Observable } from 'rxjs/internal/Observable';
import { Observable, of } from 'rxjs';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Projects } from '../../shared/project';
import { ParentTask } from '../../shared/parent-task';
import { Users } from '../../shared/user';
import { Task } from '../../shared/task';
import { UserComponent } from './user.component';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;
  let service: ProjectManagerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserComponent ],
      imports:[RouterTestingModule, FormsModule, HttpClientModule],
      providers:[ProjectManagerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.get(ProjectManagerService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define getUsersList()', ()=>{
    let mockResponse : Users[] = [
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    spyOn(service, 'getUserDetails').and.returnValue(of(mockResponse));
    component.getUserDetails();
  });

  it('should define onUserChanged()', ()=>{
    component.user = 'Krishna';
    component.users =[
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    component.onUserChanged();
    //expect(component.users.length).toBeGreaterThan(0);
  });

  it('should define add()', ()=>{
    let mockTask : Users = new Users();
    mockTask.UserId = 0;
    component.fname = 'Krishna';
    component.lname  = 'Raj';
    component.eid = 124632;
    spyOn(service, 'addUser').and.returnValue(of(''));
    component.add();
  });

  it('should define update()', ()=>{
    let mockTask : Users = new Users();
    component.uid = 2;
    component.fname = 'Krishna';
    component.lname  = 'Raj';
    component.eid = 124632;
    spyOn(service, 'updateUser').and.returnValue(of(''));
    component.update();
  });

  it('should define reset()', ()=>{
    component.reset();
    expect(component.fname).toBe('');
  });

  it('should define sortByFirstName()', ()=>{
    component.users =[
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    { "UserId" : 3, "FirstName" : 'Bala', "LastName" : 'Kumar', "EmployeeID" : 125463 },
    ];
    component.sortByFirstName();
  });

  it('should define sortByLastName()', ()=>{
    component.users =[
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    { "UserId" : 3, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 125463 },
    ];
    component.sortByLastName();
  });

  it('should define sortyById()', ()=>{
    component.users =[
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    { "UserId" : 3, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    ];
    component.sortyById();
  });

  it('should define editUser()', ()=>{
    component.users =[
      { "UserId" : 1, "FirstName" : 'Krishna', "LastName" : 'Raj', "EmployeeID" : 125632 },
    { "UserId" : 2, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 562360 },
    { "UserId" : 3, "FirstName" : 'Bala', "LastName" : 'Nandan', "EmployeeID" : 125463 },
    ];
    component.editUser(1);
    expect(component.uid).toBe(1);
  });

  it('should define deleteUser()', ()=>{
    spyOn(service, 'deleteUser').and.returnValue(of(''));
    component.deleteUser(1);
  });
});
