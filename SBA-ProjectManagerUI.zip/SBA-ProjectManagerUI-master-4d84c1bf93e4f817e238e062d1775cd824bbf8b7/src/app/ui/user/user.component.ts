import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Router} from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { ProjectManagerService } from '../../shared/project-manager.service';
import { Users } from '../../shared/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  uid:any = '';
  fname: string = '';
  lname:string  = '';
  eid:any  = '';
  user: any;
  users: Users[] = [];
  isEditClicked:boolean = false;

  constructor(private service:ProjectManagerService, private router:Router) { }

  ngOnInit() {
    localStorage.setItem("edittask",undefined);
    this.getUserDetails();
  }

getUserDetails(){
  this.users = [];
  this.service.getUserDetails().subscribe((res:Users[])=>{
    console.log(res);
    res.map(u=>{
      let user: Users = new Users();
      user.UserId = u.UserId;
      user.FirstName = u.FirstName;
      user.LastName = u.LastName;
      user.EmployeeID = u.EmployeeID;
      //user.ProjectId = u.ProjectId;
      this.users.push(user);
    });   
  }),catchError((err:any)=>
    Observable.throw(err)
  );
}

  onUserChanged(){

    if(this.user != '')
    {
      let userArr:Users[] = [];
      this.users.filter(u=>{
        if(u.FirstName.toLowerCase().match(this.user.toLowerCase()) || u.LastName.toLowerCase().match(this.user.toLowerCase()) || u.EmployeeID == this.user){
          let user:Users = new Users();
          user.UserId = u.UserId;
          user.FirstName = u.FirstName;
          user.LastName = u.LastName;
          user.EmployeeID = u.EmployeeID;
          this.users = [];
          userArr.push(user);
        }
      });
      this.users = [];
      this.users = userArr;
    }
    else if(this.user == '')
    this.ngOnInit();
  }

  add(){
    let user : Users = new Users();
    if((this.fname != '' || this.fname != undefined) && 
    (this.lname != '' && this.lname != undefined) &&
    (this.eid != '' && this.eid != undefined))
    {
        user.FirstName = this.fname;
        user.LastName =  this.lname;
        user.EmployeeID = this.eid;
        this.service.addUser(user).subscribe((res:any)=>{
          this.getUserDetails();
          this.reset();
        }),catchError((err:any)=>
          Observable.throw(err)
        );  
    }
    else
    alert('All are required field(s)');
  }

  update(){
    //this.isEditClicked = true;
    let user : Users = new Users();
    if((this.fname != '' || this.fname != undefined) && 
    (this.lname != '' && this.lname != undefined) &&
    (this.eid != '' && this.eid != undefined))
    {
        user.UserId = this.uid;
        user.FirstName = this.fname;
        user.LastName =  this.lname;
        user.EmployeeID = this.eid;
        this.service.updateUser(user).subscribe((res:any)=>{
          this.getUserDetails();
          this.reset();
        }),catchError((err:any)=>
          Observable.throw(err)
        );  
    }
    else
    alert('Please enter required field(s)');
  }

  reset()
  {
    this.uid = '';
    this.fname = '';
    this.lname = '';
    this.eid = '';
    this.isEditClicked = false;
  }

  sortByFirstName()
  {
    this.users.sort((a,b)=>{
      if(a.FirstName.toLowerCase() > b.FirstName.toLowerCase()) return -1;
      else if(a.FirstName.toLowerCase() < b.FirstName.toLowerCase()) return 1;
      else return 0;
    });
  }

  sortByLastName(){
    this.users.sort((a,b)=>{
      if(a.LastName.toLowerCase() > b.LastName.toLowerCase()) return -1;
      else if(a.LastName.toLowerCase() < b.LastName.toLowerCase()) return 1;
      else return 0;
    });
  }

  sortyById(){
    this.users.sort((a,b)=>{
      if(a.EmployeeID > b.EmployeeID) return -1;
      else if(a.EmployeeID < b.EmployeeID) return 1;
      else return 0;
    });
  }

  editUser(id: number){    
    let result : Users = new Users();
    this.isEditClicked = true;
    result = this.users.filter(u=>u.UserId == id)[0];
    this.uid = result.UserId;   
    this.fname = result.FirstName;
    this.lname = result.LastName;
    this.eid = result.EmployeeID;
  }

  deleteUser(id: number){
    if(id != undefined)
      {
          this.service.deleteUser(id).subscribe((res:any)=>{
            this.getUserDetails();
            this.reset();
          }),catchError((err:any)=>
            Observable.throw(err)
          );  
    }
    else
    alert('Invalid User ID');
  }
}
