﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace WCFJobService
{
    [ServiceContract]
    public interface IJobService
    {
        [OperationContract]
        List<Job> GetListOfJobOpenings();
        [OperationContract]
        Job GetJobOpeningByRole(string role);
    }

    [DataContract]
    public class Job
    {
        [DataMember]
        public int JobId;

        [DataMember]
        public string JobRole;
    }
}
