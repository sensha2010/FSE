﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WCFJobService
{
    public class JobService: IJobService
    {
        public List<Job> GetJobs()
        {
            List<Job> jList = new List<Job>();
            jList.Add(new Job { JobId = 8, JobRole = "Software Engineer" });
            jList.Add(new Job { JobId = 3, JobRole = "Senior Software Engineer" });
            jList.Add(new Job { JobId = 1, JobRole = "Project Manager" });
            jList.Add(new Job { JobId = 1, JobRole = "Architect" });

            return jList;
        }
        
        public List<Job> GetListOfJobOpenings()
        {
            return GetJobs();
        }
        
        public Job GetJobOpeningByRole(string role)
        {
            List<Job> jobOpeningByRole = new List<Job>();
            Job jobByRole = new Job();
            jobOpeningByRole = GetJobs();
            for(int i = 0; i < jobOpeningByRole.Count; i++)
            {
                if(jobOpeningByRole[i].JobRole == role)
                {
                    jobByRole = jobOpeningByRole[i];
                }
            }
            return jobByRole;
        }
    }
}
