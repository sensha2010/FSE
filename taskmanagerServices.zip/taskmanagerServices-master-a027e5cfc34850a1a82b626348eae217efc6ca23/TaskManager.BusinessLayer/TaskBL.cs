﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager.DataLayer;
using TaskManager.Entities;

namespace TaskManager.BusinessLayer
{
    public class TaskBL
    {
        TaskContext db;
        //TaskDL dlTask = new TaskDL();
        // Get all task Details
        public IEnumerable<TaskEntities> GetAllTask()
        {
            //return dlTask.GetAllTask();
            try
            {
                using (db = new TaskContext())
                {
                    return db.TaskEntity.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TaskEntities GetTaskByID(int id)
        {
            //return dlTask.GetTaskByID(id);
            try
            {
                using (db = new TaskContext())
                {
                    return db.TaskEntity.FirstOrDefault(t => t.TaskID == id);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void SaveTask(TaskEntities t)
        {
            //dlTask.SaveTask(t);
            TaskEntities ptNew = new TaskEntities();
            try
            {
                if(t.ParentTask != null && t.ParentTask != "")
                {
                    using (db = new TaskContext())
                    {
                        ptNew = db.TaskEntity.FirstOrDefault(tt => tt.Task == t.ParentTask);
                        if(ptNew.TaskID > 0)
                            t.ParentTaskID = ptNew.TaskID;
                    }
                }
                
                using (db = new TaskContext())
                {
                    t.Status = "In Progress";
                    db.TaskEntity.Add(t);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateTask(int id, TaskEntities t)
        {
            //dlTask.UpdateTask(id, t);
            TaskEntities tNew = new TaskEntities();
            TaskEntities ptNew = new TaskEntities();
            try
            {
                if (t.ParentTask != null && t.ParentTask != "")
                {
                    using (db = new TaskContext())
                    {
                        ptNew = db.TaskEntity.FirstOrDefault(tt => tt.Task == t.ParentTask);
                        if (ptNew.TaskID > 0)
                            t.ParentTaskID = ptNew.TaskID;
                    }
                }

                using (db = new TaskContext())
                {
                    tNew = db.TaskEntity.FirstOrDefault(tt => tt.TaskID == id);
                    tNew.Task = t.Task;
                    tNew.ParentTask = t.ParentTask;
                    tNew.ParentTaskID = t.ParentTaskID;
                    tNew.Priority = t.Priority;
                    tNew.StartDate = t.StartDate;
                    tNew.EndDate = t.EndDate;
                    tNew.Status = t.Status;
                    db.Entry(tNew).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteTask(int id)
        {
            //dlTask.DeleteTask(id);
            try
            {
                TaskEntities t = new TaskEntities();
                using (db = new TaskContext())
                {
                    t = db.TaskEntity.FirstOrDefault(task => task.TaskID == id);
                    db.TaskEntity.Remove(t);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
