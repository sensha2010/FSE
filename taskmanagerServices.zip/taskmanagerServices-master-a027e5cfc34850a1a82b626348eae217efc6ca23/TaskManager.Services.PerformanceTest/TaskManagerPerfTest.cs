﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NBench;
using TaskManager.Services.Controllers;
using TaskManager.Entities;

namespace TaskManager.Services.PerformanceTest
{
    public class TaskManagerPerfTest
    {
        public TaskController _taskController;
        private Counter _counter;
        [PerfSetup]
        public void Setup(BenchmarkContext context)
        {
            _taskController = new TaskController();
            _counter = context.GetCounter("TaskCounter");
        }

        [PerfBenchmark(NumberOfIterations = 5, RunMode = RunMode.Throughput, RunTimeMilliseconds = 5000, TestMode = TestMode.Test, SkipWarmups = true)]
        [CounterMeasurement("TaskCounter")]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 5000)]
        public void Get_Benchmark_Performance(BenchmarkContext context)
        {
            _taskController.Get();
        }

        [PerfBenchmark(NumberOfIterations = 2, RunMode = RunMode.Throughput, RunTimeMilliseconds = 5000, TestMode = TestMode.Test, SkipWarmups = true)]
        [MemoryAssertion(MemoryMetric.TotalBytesAllocated, MustBe.GreaterThanOrEqualTo, ByteConstants.SixtyFourKb)]
        public void Get_Benchmark_MemoryPerformance(BenchmarkContext context)
        {
            _taskController.Get();
        }

        [PerfBenchmark(NumberOfIterations = 3, RunMode = RunMode.Throughput, RunTimeMilliseconds = 5000, TestMode = TestMode.Test, SkipWarmups = true)]
        [GcTotalAssertion(GcMetric.TotalCollections, GcGeneration.Gen2, MustBe.GreaterThan, 0.00d)]
        public void Get_Benchmark_GCPerformance(BenchmarkContext context)
        {
            _taskController.Get();
        }

        [PerfBenchmark(NumberOfIterations = 5, RunMode = RunMode.Throughput, RunTimeMilliseconds = 5000, TestMode = TestMode.Test, SkipWarmups = true)]
        [CounterMeasurement("TaskCounter")]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 2000)]
        public void GetByID_Benchmark_Performance(BenchmarkContext context)
        {
            _taskController.Get(2005);
        }

        [PerfBenchmark(NumberOfIterations = 2, RunMode = RunMode.Throughput, RunTimeMilliseconds = 5000, TestMode = TestMode.Test, SkipWarmups = true)]
        [CounterMeasurement("TaskCounter")]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 2000)]
        public void Post_Benchmark_Performance(BenchmarkContext context)
        {
            TaskEntities t = new TaskEntities();
            t.TaskID = 0;
            t.Task = "Testing";
            t.Priority = 20;
            t.StartDate = DateTime.Now;
            t.EndDate = DateTime.Now.AddDays(1);

            _taskController.Post(t);
        }

    }
}
