﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TaskManager.BusinessLayer;
using TaskManager.Entities;

namespace TaskManager.Services.Controllers
{
    public class TaskController : ApiController
    {
        TaskBL taskBL = new TaskBL();   // Task Business layer object initialization
        // GET: api/Task
        [HttpGet]
        [Route("api/task")]
        public IEnumerable<TaskEntities> Get()
        {
            try
            {
                IEnumerable<TaskEntities> tList;
                tList = taskBL.GetAllTask();
                return tList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // GET: api/Task/5
        [HttpGet]
        [Route("api/task/{id}")]
        public TaskEntities Get(int id)
        {
            try
            {
                TaskEntities t = new TaskEntities();
                t = taskBL.GetTaskByID(id);
                return t;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // POST: api/Task
        [HttpPost]
        [Route("api/task")]
        public IHttpActionResult Post([FromBody]TaskEntities t)
        {
            try
            {
                taskBL.SaveTask(t);
                return Ok("Task Created Successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // PUT: api/Task/5
        [HttpPut]
        [Route("api/task/{id}")]
        public IHttpActionResult Put(int id, TaskEntities t)
        {
            try
            {
                taskBL.UpdateTask(id, t);
                return Ok("Task Updated Successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // DELETE: api/Task/5
        [HttpDelete]
        [Route("api/task/{id}")]
        public IHttpActionResult Delete(int id)
        {
            try
            {
                taskBL.DeleteTask(id);
                return Ok("Task Deleted Successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
