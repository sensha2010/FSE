﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager.BusinessLayer;
using TaskManager.Entities;
using NUnit.Framework;

namespace TaskManagerServices.UnitTest
{
    [TestFixture]
    public class TaskTest
    {
        TaskBL taskBL = new TaskBL();

        [Test]
        public void GetAllTask_Test()
        {
            var result = taskBL.GetAllTask();
            NUnit.Framework.Assert.Greater(result.Count(), 0);
        }

        [Test]
        public void GetTaskByID_Test()
        {
            var result = taskBL.GetTaskByID(2004);
            NUnit.Framework.Assert.AreEqual(result.TaskID, 2004);
        }

        [Test]
        public void SaveTask_Test()
        {
            TaskEntities t = new TaskEntities();
            t.TaskID = 0;
            t.Task = "Testing";
            t.Priority = 20;
            t.StartDate = DateTime.Now;
            t.EndDate = DateTime.Now.AddDays(1);

            taskBL.SaveTask(t);
            NUnit.Framework.Assert.AreEqual(t.StartDate.Date, DateTime.Now.Date);
        }

        [Test]
        public void UpdateTask_Test()
        {
            int taskID = 2004;
            TaskEntities testTask = new TaskEntities();
            testTask.TaskID = taskID;
            testTask.Task = "Requirement Gathering";
            testTask.Priority = 25;
            testTask.StartDate = DateTime.Now.AddDays(-3);
            testTask.EndDate = DateTime.Now.AddDays(-2);

            taskBL.UpdateTask(taskID, testTask);
            NUnit.Framework.Assert.Greater(testTask.TaskID, 0);
        }

        [Test]
        public void DeleteTask_Test()
        {
            var result = taskBL.GetAllTask();

            result = result.OrderByDescending(t => t.TaskID);
            int taskID = 3003;
            taskBL.DeleteTask(taskID);
            NUnit.Framework.Assert.Greater(taskID, 0);
        }
    }
}
