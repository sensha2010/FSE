import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { AddComponent } from './ui/add/add.component';
import { EditComponent } from './ui/edit/edit.component';
import { ViewComponent } from './ui/view/view.component';

const routes:Routes = [
  { path:'', redirectTo:'view', pathMatch: 'full' },
  { path:'add', component: AddComponent },
  { path: 'edit', component : EditComponent },
  { path: 'view', component: ViewComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  declarations: [],
  exports:[ RouterModule]
})
export class AppRoutingModule { }
