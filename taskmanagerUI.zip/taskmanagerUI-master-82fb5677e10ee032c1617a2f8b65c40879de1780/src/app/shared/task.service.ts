import { Injectable } from '@angular/core';
import { observable, of } from 'rxjs';
import { map,catchError } from "rxjs/operators";
import { HttpModule, Http, Headers, Response, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders,HttpClientModule } from '@angular/common/http';

import { TaskDetail } from '../task-detail';
import { Observable } from 'rxjs/internal/Observable';
import { throwError } from 'rxjs/internal/observable/throwError';
//import { post } from 'selenium-webdriver/http';

@Injectable()
export class TaskService{
    taskList: TaskDetail[] = [];
    baseUrl:any;
    requestOptions :RequestOptions;
    headers:HttpHeaders = new HttpHeaders({'Accept':'application/json', 'Content-Type':'application/json','Access-Control-Allow-Origin':'*'});

    constructor(private http: HttpClient){
        //this.requestOptions = new RequestOptions({headers:this.headers,withCredentials:true});
        //this.baseUrl = 'http://localhost:56748/api/';
        this.baseUrl = 'http://localhost:8092/TaskManagerService/api/'
    }

    getTaskDetails(): Observable<TaskDetail[]>{
        return this.http.get<TaskDetail[]>(this.baseUrl + 'task').pipe(
            catchError(this.handleError('getTaskDetails',[]))
        );
    }

    getTaskDetailById(taskId: string): Observable<TaskDetail>
    {
        return this.http.get<TaskDetail>(this.baseUrl + 'task/'+ taskId).pipe(
            catchError(this.handleError('getTaskDetailById', null))
        );
    }

    addTaskDetail(task:TaskDetail):Observable<TaskDetail>{
        const headers = new HttpHeaders({'Content-Type':'application/json','Accept':'application/json'});
        var body = JSON.stringify(task);
        console.log(task);
        console.log(this.baseUrl + 'task');
        return this.http.post<TaskDetail>(this.baseUrl + 'task', body, {headers:headers}).pipe(map(
            (res:Response)=> res),
            catchError(this.handleError('addTaskDetail', task))
          );
    }

    updateTaskDetail(task:TaskDetail):Observable<TaskDetail>{
        const headers = new HttpHeaders({'Accept':'application/json', 'Content-Type':'application/json','Access-Control-Allow-Origin':'*'});
        var body = JSON.stringify(task);
        
        return this.http.put<TaskDetail>(this.baseUrl + 'task/' + task.TaskID,body,{headers:headers}).pipe(
            catchError(this.handleError('updateTaskDetail', task))
          );
    }

        deleteTaskDetail(tid:string):Observable<any>
        {
            return this.http.delete<TaskDetail>(this.baseUrl + 'task/'+ tid).pipe(
                catchError(this.handleError('deleteTaskDetail',[]))
            );
        }

    private handleError<T> (operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
          console.error(error); // log to console instead
          return of(result as T);
        };
      }

}