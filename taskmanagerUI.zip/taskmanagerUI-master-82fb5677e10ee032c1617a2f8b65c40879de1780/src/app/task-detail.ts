export class TaskDetail{
    TaskID: string;
    ParentTaskID: string;
    Task:string;
    ParentTask:string;
    Priority:number;
    Status:string;
    StartDate:string;
    EndDate:string;
}