import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskService } from 'src/app/shared/task.service';
import { TaskDetail } from '../../task-detail';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { AddComponent } from './add.component';

describe('AddComponent', () => {
  let component: AddComponent;
  let service : TaskService;
  let fixture: ComponentFixture<AddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddComponent ],
      imports:[RouterTestingModule, ReactiveFormsModule, HttpClientModule],
      providers:[TaskService],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.get(TaskService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test ngOnint() method', ()=>{
    component.ngOnInit();
    expect(component.addForm).not.toBeNull();
  });

  it('should test dateLessThan() method with to date greater than from date', ()=>{
        component.dateLessThan('2018-03-23', '2018-03-24');
  });

  it('should test dateLessThan() method with to date less than from date', ()=>{
    component.dateLessThan('2018-03-24', '2018-03-23');
});

    it('should test reset() method', ()=>{
        component.reset();
    });

    it('should test f get() method', ()=>{
        component.f;
    });

  it('should test onSubmit() method', ()=>{
    component.addForm.controls["task"].setValue("test data");
    component.addForm.controls["parentTask"].setValue("");
    component.addForm.controls["priority"].setValue(5);
    component.addForm.controls["endDate"].setValue("2019-03-27");
    component.addForm.controls["startDate"].setValue("2019-03-27");

    component.onSubmit();
    expect(component.addForm.valid).toBeTruthy();
  });

  it('should test onSubmit() method with invalid form values', ()=>{
    component.addForm.controls["task"].setValue("");
    component.addForm.controls["parentTask"].setValue("");
    component.addForm.controls["priority"].setValue(5);
    component.addForm.controls["endDate"].setValue("");
    component.addForm.controls["startDate"].setValue("2019-03-27");

    component.onSubmit();
    expect(component.addForm.valid).toBeFalsy();
  });
});
