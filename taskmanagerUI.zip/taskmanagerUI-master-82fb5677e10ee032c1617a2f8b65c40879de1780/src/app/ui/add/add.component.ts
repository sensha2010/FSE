import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from 'src/app/shared/task.service';
import { TaskDetail } from '../../task-detail';
import { FormGroup, FormBuilder, Validators, FormsModule } from '@angular/forms';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private router:Router, private service:TaskService, private formBuilder:FormBuilder) { }
  addForm: FormGroup;
  model: any = {};
  registerForm: FormGroup;
  submitted = false;
  
  ngOnInit() {

    this.addForm = this.formBuilder.group({
      task: ['', Validators.required],
      priority: ['', Validators.required],
      parentTask: ['',],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
  }, { validator: this.dateLessThan('startDate', 'endDate')});
  }

  dateLessThan(from: string, to: string) {
    return (group: FormGroup): {[key: string]: any} => {
      let f = group.controls[from];
      let t = group.controls[to];
      if(f.value != '' && t.value != '')
      {
        if (f.value > t.value) {
          alert("Date from should be less than Date to");
          return {
            dates: "Date from should be less than Date to"
          };
        }
        return {};
      }
    }
}
  get f() { return this.addForm.controls; }

    onSubmit() {
      let taskdetail:any;
        this.submitted = true;
        taskdetail = this.addForm.value;
        console.log(this.addForm.value);
        if (this.addForm.invalid) {
            alert('Invalid form values');
        }
        else
        this.service.addTaskDetail(taskdetail).subscribe((res:any)=>{
          this.router.navigate(["view"]);
        }),catchError((err:any)=>
          Observable.throw(err)
        );
    }
  
  reset(){
    this.addForm.reset({task : '', priority : '', parentTask : '', startDate : '', endDate : ''});
  }
}
