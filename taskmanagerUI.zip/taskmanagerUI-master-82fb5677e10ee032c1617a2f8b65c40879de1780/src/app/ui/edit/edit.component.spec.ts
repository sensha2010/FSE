import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskService } from 'src/app/shared/task.service';
import { TaskDetail } from '../../task-detail';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';
import { EditComponent } from './edit.component';

describe('EditComponent', () => {
  let component: EditComponent;
  let fixture: ComponentFixture<EditComponent>;
  
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditComponent ],
      imports:[RouterTestingModule, ReactiveFormsModule, HttpClientModule],
      providers:[TaskService, { provide: FormBuilder, useValue: formBuilder }]
    })
    .compileComponents();
  }));
  
  beforeEach(() => {
    debugger;
    fixture = TestBed.createComponent(EditComponent);
    component = fixture.componentInstance;
    
    component.editForm = formBuilder.group({
      TaskID: null,
      Task: "test data",
      Priority:null,
      StartDate:null,
      ParentTask:null,
      EndDate:null,
      Status:null
  });
    fixture.detectChanges();
  });
 
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should called ngOnint()', () => {
    localStorage.setItem("edittask","2005");
      component.ngOnInit();
    expect(component.task).not.toBeNull();
  });

  // it('should test onSubmit() method', ()=>{
  //   component.editForm.controls["Task"].setValue("test data");
  //   component.editForm.controls["ParentTask"].setValue("");
  //   component.editForm.controls["Priority"].setValue(5);
  //   component.editForm.controls["EndDate"].setValue("2019-03-27");
  //   component.editForm.controls["StartDate"].setValue("2019-03-27");
  //   component.editForm.controls["Status"].setValue("In Progress");

  //   component.onSubmit();
  // });

});

