import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormBuilder, FormGroup, Validators, ReactiveFormsModule} from '@angular/forms';
import { TaskService } from '../../shared/task.service';
import { TaskDetail } from '../../task-detail';
import {Router} from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  constructor( private service: TaskService,
    public router: Router, private formBuilder: FormBuilder) { }
  editForm: FormGroup;
  task:TaskDetail = new TaskDetail();
  //startDate:any = '';
  submitted:boolean = false;
  ngOnInit() {
    debugger;
    let taskID = localStorage.getItem("edittask");
    if(!taskID) {
      alert("Invalid task id.")
      this.router.navigate(['view']);
      return;
    }
    this.editForm = this.formBuilder.group({
      TaskID:['', Validators.required],
      Task: ['', Validators.required],
      ParentTask:['', Validators.required],
      Priority: ['', Validators.required],
      StartDate: ['', Validators.required],
      EndDate: ['', Validators.required],
      Status:['', Validators.required]
    });

    
    this.service.getTaskDetailById(taskID).subscribe(res=>{      
      this.task = new TaskDetail();
      this.task.Task = res.Task;
      this.task.TaskID = res.TaskID;
      if(res.ParentTask != undefined)
        this.task.ParentTask = res.ParentTask;
      else
        this.task.ParentTask ='';
      this.task.ParentTaskID = res.ParentTaskID;
      this.task.Priority = res.Priority;
      this.task.StartDate = this.getDateFormatString(res.StartDate);
      this.task.EndDate = this.getDateFormatString(res.EndDate);
      this.task.Status = res.Status;

      this.editForm.setValue({
        TaskID: this.task.TaskID,
        Task: this.task.Task, 
        ParentTask:this.task.ParentTask,
        Priority : this.task.Priority,
        StartDate: this.task.StartDate, 
        EndDate : this.task.EndDate,
        Status:this.task.Status
      });
    });
  }
  
  get f() { return this.editForm.controls; }

  getDateFormatString(date:string):string
  {
    let dateArr:any;
    dateArr = date.split('T');
    return dateArr[0];
  }
  cancel()
  {
    this.router.navigate(['view']);
  }

  onSubmit()
  {
    this.submitted = true;
    this.service.updateTaskDetail(this.editForm.value).subscribe(res=>{
      this.router.navigate(["view"]);
    }),catchError((err:any)=>{
      console.error(err);
      return Observable.throw(err);
    });
  }
}
