import { Component, OnInit, ViewChild, Inject, Injector, HostListener } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TaskService } from '../../shared/task.service';
import { TaskDetail } from '../../task-detail';
import {Router} from "@angular/router";
import { catchError } from 'rxjs/internal/operators/catchError';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  constructor(private service:TaskService, private router:Router, private inject:Injector) { }

  taskList: TaskDetail[] = []; 
  task:any;
  parentTask:any;
  fpriority:any;
  tpriority:any;
  startDate:any;
  endDate:any;
  tsDate:any;
  teDate:any;

  ngOnInit() {
    this.taskList = [];
    this.service.getTaskDetails().subscribe(res=>{
      res.forEach(tl=>{
        let tlNew : TaskDetail = new TaskDetail();
        tlNew.TaskID = tl.TaskID;
        tlNew.Task = tl.Task;
        tlNew.ParentTaskID = tl.ParentTaskID;
        tlNew.ParentTask = tl.ParentTask;
        tlNew.Priority = tl.Priority;
        tlNew.StartDate = tl.StartDate;
        tlNew.EndDate = tl.EndDate;
        if(tl.Status == null || tl.Status === undefined)
          tl.Status = 'In Progress';
        else if(tl.Status != null)
          tlNew.Status = tl.Status;
        this.taskList.push(tl);
      })
    });
  }

  onTaskChanged()
  {
    if(this.task != '')
    {
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        if(tl.Task.toLocaleLowerCase().match(this.task.toLocaleLowerCase())){
          let taskdtl:TaskDetail = new TaskDetail();
          taskdtl.TaskID = tl.TaskID;
          taskdtl.Task = tl.Task;
          taskdtl.ParentTaskID = tl.ParentTaskID;
          taskdtl.ParentTask = tl.ParentTask;
          taskdtl.Priority = tl.Priority;
          taskdtl.StartDate = tl.StartDate;
          taskdtl.EndDate = tl.EndDate;
          taskdtl.Status = tl.Status;
          this.taskList = [];
          taskArr.push(taskdtl);
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.task == '')
    this.ngOnInit();
  }

  onParentTaskChanged(){
    if(this.parentTask != '')
    {
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        if(tl.ParentTask != null)
        {
          if(tl.ParentTask.toLocaleLowerCase().match(this.parentTask.toLocaleLowerCase())){
            let taskdtl:TaskDetail = new TaskDetail();
            taskdtl.TaskID = tl.TaskID;
            taskdtl.Task = tl.Task;
            taskdtl.ParentTaskID = tl.ParentTaskID;
            taskdtl.ParentTask = tl.ParentTask;
            taskdtl.Priority = tl.Priority;
            taskdtl.StartDate = tl.StartDate;
            taskdtl.EndDate = tl.EndDate;
            taskdtl.Status = tl.Status;
            this.taskList = [];
            taskArr.push(taskdtl);
          }
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.parentTask == '')
    this.ngOnInit();
  }

  onPriorityFChanged(){
    if(this.fpriority != '')
    {
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        if(tl.Priority == this.fpriority){
          let taskdtl:TaskDetail = new TaskDetail();
          taskdtl.TaskID = tl.TaskID;
          taskdtl.Task = tl.Task;
          taskdtl.ParentTaskID = tl.ParentTaskID;
          taskdtl.ParentTask = tl.ParentTask;
          taskdtl.Priority = tl.Priority;
          taskdtl.StartDate = tl.StartDate;
          taskdtl.EndDate = tl.EndDate;
          taskdtl.Status = tl.Status;
          this.taskList = [];
          taskArr.push(taskdtl);
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.fpriority == '')
    this.ngOnInit();
  }

  onPriorityTChanged(){
    if(this.tpriority != '')
    {
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        if(tl.Priority == this.tpriority){
          let taskdtl:TaskDetail = new TaskDetail();
          taskdtl.TaskID = tl.TaskID;
          taskdtl.Task = tl.Task;
          taskdtl.ParentTaskID = tl.ParentTaskID;
          taskdtl.ParentTask = tl.ParentTask;
          taskdtl.Priority = tl.Priority;
          taskdtl.StartDate = tl.StartDate;
          taskdtl.EndDate = tl.EndDate;
          taskdtl.Status = tl.Status;
          this.taskList = [];
          taskArr.push(taskdtl);
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.tpriority == '')
    this.ngOnInit();
  }
  ontsDateChanged()
  {
    if(this.tsDate != '')
    {
      console.log(this.tsDate);
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        console.log(tl.StartDate.split('T')[0]);
        if(tl.StartDate.split('T')[0] == this.tsDate){
          let taskdtl:TaskDetail = new TaskDetail();
          taskdtl.TaskID = tl.TaskID;
          taskdtl.Task = tl.Task;
          taskdtl.ParentTaskID = tl.ParentTaskID;
          taskdtl.ParentTask = tl.ParentTask;
          taskdtl.Priority = tl.Priority;
          taskdtl.StartDate = tl.StartDate;
          taskdtl.EndDate = tl.EndDate;
          taskdtl.Status = tl.Status;
          this.taskList = [];
          taskArr.push(taskdtl);
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.tsDate == '')
    this.ngOnInit();
  }

  onteDateChanged()
  {
    if(this.teDate != '')
    {
      let taskArr:TaskDetail[] = [];
      this.taskList.filter(tl=>{
        if(tl.EndDate.split('T')[0] == this.teDate){
          let taskdtl:TaskDetail = new TaskDetail();
          taskdtl.TaskID = tl.TaskID;
          taskdtl.Task = tl.Task;
          taskdtl.ParentTaskID = tl.ParentTaskID;
          taskdtl.ParentTask = tl.ParentTask;
          taskdtl.Priority = tl.Priority;
          taskdtl.StartDate = tl.StartDate;
          taskdtl.EndDate = tl.EndDate;
          taskdtl.Status = tl.Status;
          this.taskList = [];
          taskArr.push(taskdtl);
        }
      });
      this.taskList = [];
      this.taskList = taskArr;
    }
    else if(this.teDate == '')
    this.ngOnInit();
  }

  editTask(taskid:string)
  {
    //localStorage.removeItem("edittask");
    localStorage.setItem("edittask",taskid);
    this.router.navigate(["edit"]);
  }

  endTask(t:TaskDetail)
  {
    t.Status = 'Completed';
    this.service.updateTaskDetail(t).subscribe(res=>{
      this.ngOnInit();
    }),catchError((err:any)=>{
      console.error(err);
      return Observable.throw(err);
    });
  }

  deleteTask(id:string)
  {
    this.service.deleteTaskDetail(id).subscribe(res=>{
      this.ngOnInit();
    }),catchError((err:any)=>{
      console.error(err);
      return Observable.throw(err);
    })
  }

}
